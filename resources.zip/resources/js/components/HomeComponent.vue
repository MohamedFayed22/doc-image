<template>
    <div class="container">
        <div class="row">
            <div class="logo col-12 "><img src="templates/images/logo.png" /></div>
            <div class="col-12 col-lg-6"><a href="/upload"  class="btn btn-outline-primary btn-lg btn-block mb-3">UPLOAD</a></div>
            <div class="col-12 col-lg-6"><a href="/print" class="btn btn-outline-success btn-lg btn-block mb-3">PRINT</a></div>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>
